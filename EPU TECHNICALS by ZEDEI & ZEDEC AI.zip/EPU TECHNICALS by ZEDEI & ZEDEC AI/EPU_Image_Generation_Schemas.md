# EPU Device - ChatGPT-4 Image Generation Schemas

**Purpose**: Create photorealistic technical images of the Emotional Processing Unit (EPU) for NVIDIA/AMD presentations  
**Target**: Professional semiconductor marketing materials  
**Style**: Technical precision meets futuristic aesthetics  

## Schema 1: EPU Chip Die Photography

**Prompt for ChatGPT-4 DALL-E**:
```
Create a professional macro photograph of a cutting-edge semiconductor chip die. The chip is square, approximately 7mm x 7mm, with a distinctive dual-tone design. The left half features a dark metallic surface with intricate geometric patterns in a deep forest green (#002911), while the right half shows a bright, almost luminescent surface with fine circuit patterns in electric green (#00FF6A). 

In the center, there's a unique cross-sectional area showing layered materials: a red piezoelectric layer (PZT), a blue-green magnetostrictive layer (Terfenol-D), and an ultra-thin silver insulator line between them. Golden bond wires connect to pads around the perimeter.

The chip sits on a high-tech black substrate with "EPU-001" laser-etched in modern sans-serif font. Dramatic studio lighting creates subtle reflections on the metallic surfaces. The background is gradient black to dark blue. Include small text overlay: "ZEDEC-ZEDEI EPU | Consciousness Computing | 3nm Process | 64 ME Cores + 32 Qubits"

Style: Professional semiconductor product photography, macro lens, shallow depth of field, high contrast lighting, photorealistic detail.
```

## Schema 2: EPU System Architecture Visualization

**Prompt for ChatGPT-4 DALL-E**:
```
Create a sophisticated 3D technical diagram showing the internal architecture of an Emotional Processing Unit (EPU). The image shows a transparent cubic chip housing revealing multiple layers:

Top layer: Array of 64 small square magnetoelectric cores arranged in an 8x8 grid, each core glowing with alternating magnetic field lines (horizontal, green) and electric field lines (vertical, yellow) at perfect 90-degree angles.

Middle layer: A crystalline quantum buffer array with 32 superconducting qubits, each represented as a small sphere with swirling quantum state visualizations in purple and blue, connected by golden waveguides.

Bottom layer: The EmotionBus waveguide system - a network of optical channels in bright cyan carrying emotional data packets, with bandwidth indicators showing "1 THz" in technical font.

The entire system is enclosed in a sleek black semiconductor package with "EPU" embossed on top. Data flow arrows in rainbow colors (representing different emotions) enter from the left and exit as processed quantum states on the right.

Background: High-tech laboratory setting with holographic displays showing emotional waveforms and technical specifications. Include small overlay text: "Heart=Magnetic : Mind=Electric @ 90°"

Style: High-tech 3D visualization, clean scientific aesthetic, dramatic lighting with subtle blue ambient glow, photorealistic materials and textures.
```

## Schema 3: EPU in Computing Environment

**Prompt for ChatGPT-4 DALL-E**:
```
Create a professional technology showcase image featuring the EPU (Emotional Processing Unit) integrated into a modern computing system. 

Foreground: A sleek, modern workstation with dual monitors displaying colorful emotional processing visualizations - brain wave patterns, heart rate variability graphs, and real-time emotion classification results. The monitors show "ZEDEC-ZEDEI EPU Dashboard" with metrics like "Emotions/Sec: 1,000,000" and "Coherence Extension: 10x".

Center: An open computer case revealing a high-end graphics card modified with a distinctive EPU co-processor module. The EPU module glows with soft green and pink accents (#00FF6A and #FF0095), showing its active emotional processing state. Cable management is pristine with custom-colored cables.

Background: A modern tech workspace with multiple workstations, suggesting a research and development lab. Subtle holographic projections float above showing magnetoelectric field visualizations and quantum state diagrams.

People: In the background, blurred figures of engineers and researchers working collaboratively, suggesting the human element of consciousness computing.

Text overlays: "NVIDIA GeForce RTX + EPU Co-Processor" and "AMD Radeon + EPU Integration" on different monitor displays, emphasizing compatibility with both ecosystems.

Style: Professional technology marketing photography, clean modern aesthetic, excellent lighting, realistic materials and reflections, depth of field focusing on the EPU hardware.
```

## Schema 4: EPU Manufacturing Process

**Prompt for ChatGPT-4 DALL-E**:
```
Create a high-tech semiconductor fabrication facility image showing the EPU manufacturing process. 

Scene: A pristine cleanroom environment with yellow lighting typical of semiconductor fabs. Robotic wafer handling systems move 300mm silicon wafers between processing stations.

Foreground: A cross-sectional technical diagram floating holographically in the air, showing the EPU layer stack:
- Silicon substrate (gray)
- Platinum bottom electrode (metallic silver)
- PZT piezoelectric layer (bright red, 500nm thick, labeled)
- Al₂O₃ insulator (thin blue line, 2nm, labeled)
- Terfenol-D magnetostrictive layer (blue-green, 1000nm thick, labeled)
- Gold top electrode (golden yellow, labeled)

Background: Advanced processing equipment including:
- PVD (Physical Vapor Deposition) chamber for Terfenol-D
- CVD (Chemical Vapor Deposition) system for PZT
- Electron beam lithography for nanoscale patterning
- Quantum module assembly station

Technical displays show process parameters: "Temperature: 450°C", "Pressure: 10⁻⁶ Torr", "Deposition Rate: 2 Å/s"

Text overlay: "3nm Process Node | ME Layer Integration | TSMC/Samsung Compatible"

Style: Professional industrial photography, clean high-tech aesthetic, sophisticated lighting highlighting the precision equipment, photorealistic detail with scientific accuracy.
```

## Schema 5: EPU Market Applications Montage

**Prompt for ChatGPT-4 DALL-E**:
```
Create a dynamic lifestyle and technology montage showing EPU applications across multiple industries.

Layout: Split into four quadrants representing different markets:

Top Left - Healthcare: A patient wearing a sleek EEG headset connected to an EPU-powered system, with a holographic brain displaying real-time emotional states in beautiful color gradients. Medical professional reviewing personalized therapy recommendations on a tablet.

Top Right - Gaming/Entertainment: A gamer wearing VR glasses, completely immersed in an emotional-responsive virtual world where the environment changes color and music based on their feelings. The EPU hardware glows within a high-performance gaming rig.

Bottom Left - Education: Students in a modern classroom using EPU-powered adaptive learning tablets that respond to their emotional engagement levels. Stress indicators and focus metrics display in real-time, helping optimize learning experiences.

Bottom Right - AI/Robotics: A sophisticated humanoid robot with empathic capabilities, its chest panel showing the EPU's emotional processing core. The robot is interacting naturally with humans, displaying appropriate emotional responses through LED patterns.

Center: The ZEDEC-ZEDEI logo with "Consciousness Computing Platform" underneath, connecting all applications with flowing data streams in rainbow colors representing emotional bandwidth.

Style: Futuristic lifestyle photography, vibrant colors emphasizing the emotional aspects of technology, professional lighting, diverse and inclusive representation of users, optimistic technology vision.
```

## Schema 6: EPU Chip Package Detail

**Prompt for ChatGPT-4 DALL-E**:
```
Create an extreme close-up, macro photography image of the EPU chip package showing intricate technical details.

Focus: A premium BGA (Ball Grid Array) package, approximately 25mm x 25mm, with a sophisticated multi-layer design:

Top surface: Matte black ceramic substrate with "EPU" laser-etched in precise, modern typography. The ZEDEC-ZEDEI logo (stylized) embossed subtly in one corner.

Visible features:
- Precision-cut heat spreader with micro-fins for thermal management
- Golden electrical contacts arranged in perfect geometric patterns
- Tiny LED indicators showing system status (green for operational, blue for quantum coherence active)
- QR code containing chip authentication data
- Serial number "EPU240719001" in technical font

Surrounding details:
- PCB substrate with visible trace routing in green solder mask
- Surface-mount components (capacitors, resistors) for power conditioning
- Thermal interface material visible around the package edges

Lighting: Professional macro photography lighting revealing surface textures, engravings, and reflective properties of different materials.

Background: Technical drawing paper with partial EPU specifications visible as subtle background elements.

Style: Ultra-high detail macro photography, professional product photography lighting, technical precision, photorealistic material rendering.
```

## Schema 7: ZEDEC-ZEDEI Lab Environment

**Prompt for ChatGPT-4 DALL-E**:
```
Create an inspiring R&D laboratory scene showing the ZEDEC-ZEDEI development environment.

Setting: A modern, open-concept research facility with floor-to-ceiling windows showing a sunset sky. The space combines high-tech equipment with organic, human-centered design elements.

Workstations: Multiple desk setups with EPU development boards, oscilloscopes, spectrum analyzers, and quantum measurement equipment. Large curved monitors display:
- Real-time EPU emotional processing data
- Quantum coherence measurements
- Magnetoelectric field simulations
- ZEDEC.ai website interface (visible but blurred)

Center piece: A holographic projection table showing a 3D model of the EPU architecture with interactive elements. Team members can manipulate the hologram to explore different design aspects.

People: Diverse team of engineers and researchers collaborating around the holographic display, pointing at specific components and discussing optimizations. Their body language suggests excitement and breakthrough moments.

Technical elements:
- EPU prototype boards on various desks
- Test equipment showing successful measurements
- Whiteboards with equations for magnetoelectric coupling
- 3D printed prototypes and material samples

Ambiance: Warm, inspiring lighting that balances high-tech precision with human creativity. Natural elements like plants integrated throughout the space.

Text overlay: "ZEDEC-ZEDEI Unified R&D | Consciousness Computing Innovation Lab"

Style: Professional corporate photography, inspiring technology workspace aesthetic, warm lighting, authentic collaboration moments, future-forward design.
```

## Technical Accuracy Guidelines

### Color Palette Consistency
- **ZEDEC Core Green**: #00FF6A (electric, mind-focused)
- **ZEDEC Dark**: #002911 (deep, consciousness-depth)
- **ZEDEI Signal**: #FF0095 (dynamic, implementation-focused)
- **Quantum Purple**: #DDA0DD (quantum states)
- **Magnetoelectric Blue**: #4ECDC4 (field coupling)

### Material Representations
- **Silicon**: Dark gray, matte finish
- **Gold**: Bright metallic, highly reflective
- **PZT**: Bright red, ceramic appearance
- **Terfenol-D**: Blue-green, metallic luster
- **Superconductors**: Smooth, mirror-like surface with quantum shimmer

### Typography Standards
- **Technical Labels**: Clean sans-serif (Helvetica, Arial)
- **Branding**: Modern, technology-focused fonts
- **Specifications**: Monospace for technical data

### Lighting Requirements
- **Professional**: Studio-quality lighting for all technical shots
- **Dramatic**: High contrast for chip photography
- **Warm**: Human-centered lighting for application scenes
- **Scientific**: Clean, even lighting for laboratory environments

---

**Usage Instructions**:
1. Copy individual schema prompts into ChatGPT-4 with DALL-E access
2. Generate images iteratively, refining details as needed
3. Use generated images for NVIDIA/AMD presentation materials
4. Maintain consistent branding and technical accuracy across all images

**Output Requirements**:
- Minimum resolution: 2048x2048 pixels
- Professional quality suitable for corporate presentations
- Technically accurate representations of semiconductor technology
- Emotionally compelling while maintaining scientific credibility
