#!/bin/bash

# CURZI-ZEDEI Audit Engine – Master Config Validator
# Validates the master configuration for recursive trinary interconnection
# Ensures all scripts, groups, and global configurations align with Rodin Coil and Tesla patterns
# Created by: 36N9_Genetics_LLC_Michael_Laurence_Curzi

# Configuration
MASTER_CONFIG_FILE="/Users/36n9/CascadeProjects/AUDIT_ENGINES/curzi_zedei/omni/master_config.json"
VALIDATION_LOG="/tmp/curzi_master_config_validation.log"
SCRIPT_BASE="/Users/36n9/CascadeProjects/AUDIT_ENGINES/curzi_zedei/omni"

# Initialize logging
function log_message() {
    local timestamp=$(date -u +"%Y-%m-%dT%H:%M:%SZ")
    local message="$1"
    echo "[$timestamp] $message" >> "$VALIDATION_LOG"
    echo "[$timestamp] $message"
}

# Check if required tools are available
function check_requirements() {
    if ! command -v jq &> /dev/null; then
        log_message "ERROR: 'jq' is required but not installed. Please install jq to parse JSON."
        exit 1
    fi
    log_message "All required tools are available."
}

# Validate Master Config File Existence
function validate_config_existence() {
    if [[ -f "$MASTER_CONFIG_FILE" ]]; then
        log_message "Master configuration file found at $MASTER_CONFIG_FILE"
        return 0
    else
        log_message "ERROR: Master configuration file not found at $MASTER_CONFIG_FILE"
        return 1
    fi
}

# Validate JSON Structure
function validate_json_structure() {
    log_message "Validating JSON structure of master configuration..."
    if jq '.' "$MASTER_CONFIG_FILE" > /dev/null 2>&1; then
        log_message "JSON structure is valid."
        return 0
    else
        log_message "ERROR: Invalid JSON structure in $MASTER_CONFIG_FILE"
        return 1
    fi
}

# Validate Rodin Coil Channels
function validate_rodin_channels() {
    log_message "Validating Rodin Coil channel configuration..."
    local channels=$(jq -r '.configuration.rodin_coil_channels' "$MASTER_CONFIG_FILE")
    if [[ $channels -eq 16384 ]]; then
        log_message "Rodin Coil channels correctly set to 16384."
        return 0
    else
        log_message "ERROR: Rodin Coil channels set to $channels, expected 16384."
        return 1
    fi
}

# Validate Tesla Pattern
function validate_tesla_pattern() {
    log_message "Validating Tesla pattern configuration..."
    local pattern=$(jq -r '.configuration.tesla_pattern[]' "$MASTER_CONFIG_FILE" | tr '
' ' ')
    if [[ "$pattern" == "3 6 9 " ]]; then
        log_message "Tesla pattern correctly set to [3, 6, 9]."
        return 0
    else
        log_message "ERROR: Tesla pattern set to [$pattern], expected [3, 6, 9]."
        return 1
    fi
}

# Validate Rodin Pattern
function validate_rodin_pattern() {
    log_message "Validating Rodin pattern configuration..."
    local pattern=$(jq -r '.configuration.rodin_pattern[]' "$MASTER_CONFIG_FILE" | tr '
' ' ')
    if [[ "$pattern" == "1 2 4 8 7 5 " ]]; then
        log_message "Rodin pattern correctly set to [1, 2, 4, 8, 7, 5]."
        return 0
    else
        log_message "ERROR: Rodin pattern set to [$pattern], expected [1, 2, 4, 8, 7, 5]."
        return 1
    fi
}

# Validate Script Existence
function validate_script_existence() {
    log_message "Validating existence of scripts defined in master configuration..."
    local scripts=$(jq -r '.configuration.trinary_levels.script.scripts[]' "$MASTER_CONFIG_FILE")
    local missing_scripts=0
    
    for script in $scripts; do
        if [[ -f "$SCRIPT_BASE/$script" ]]; then
            log_message "Script found: $script"
        else
            log_message "ERROR: Script not found: $script"
            ((missing_scripts++))
        fi
    done
    
    if [[ $missing_scripts -eq 0 ]]; then
        log_message "All scripts defined in configuration exist."
        return 0
    else
        log_message "ERROR: $missing_scripts scripts are missing."
        return 1
    fi
}

# Validate Group Configuration
function validate_group_configuration() {
    log_message "Validating group configuration in master configuration..."
    local group1_count=$(jq -r '.configuration.trinary_levels.group.groups.group_1 | length' "$MASTER_CONFIG_FILE")
    local group2_count=$(jq -r '.configuration.trinary_levels.group.groups.group_2 | length' "$MASTER_CONFIG_FILE")
    local group3_count=$(jq -r '.configuration.trinary_levels.group.groups.group_3 | length' "$MASTER_CONFIG_FILE")
    
    if [[ $group1_count -gt 0 && $group2_count -gt 0 && $group3_count -gt 0 ]]; then
        log_message "Group configurations are defined with scripts."
        return 0
    else
        log_message "ERROR: One or more groups are empty or undefined."
        return 1
    fi
}

# Validate Global Execution Flow
function validate_global_execution_flow() {
    log_message "Validating global execution flow in master configuration..."
    local phases=$(jq -r '.configuration.trinary_levels.global.execution_flow | keys[]' "$MASTER_CONFIG_FILE" | grep 'phase')
    local feedback=$(jq -r '.configuration.trinary_levels.global.execution_flow.feedback_loop' "$MASTER_CONFIG_FILE")
    
    if [[ -n "$phases" && -n "$feedback" ]]; then
        log_message "Global execution flow and feedback loop are defined."
        return 0
    else
        log_message "ERROR: Global execution flow phases or feedback loop are not properly defined."
        return 1
    fi
}

# Validate Omni-Dimensional Paths
function validate_omni_paths() {
    log_message "Validating omni-dimensional paths in master configuration..."
    local paths=$(jq -r '.configuration.omni_dimensional_paths[]' "$MASTER_CONFIG_FILE")
    local valid_paths=0
    
    for path in $paths; do
        if [[ -d "$path" ]]; then
            log_message "Path accessible: $path"
            ((valid_paths++))
        else
            log_message "WARNING: Path not accessible: $path"
        fi
    done
    
    if [[ $valid_paths -gt 0 ]]; then
        log_message "At least one omni-dimensional path is accessible."
        return 0
    else
        log_message "ERROR: No omni-dimensional paths are accessible."
        return 1
    fi
}

# Main Validation Function
function main_validation() {
    log_message "Starting validation of CURZI-ZEDEI Audit Engine master configuration"
    check_requirements
    
    local validation_errors=0
    
    validate_config_existence || ((validation_errors++))
    validate_json_structure || ((validation_errors++))
    validate_rodin_channels || ((validation_errors++))
    validate_tesla_pattern || ((validation_errors++))
    validate_rodin_pattern || ((validation_errors++))
    validate_script_existence || ((validation_errors++))
    validate_group_configuration || ((validation_errors++))
    validate_global_execution_flow || ((validation_errors++))
    validate_omni_paths || ((validation_errors++))
    
    if [[ $validation_errors -eq 0 ]]; then
        log_message "VALIDATION SUCCESSFUL: Master configuration for CURZI-ZEDEI Audit Engine is valid."
        echo "VALIDATION SUCCESSFUL: All checks passed for the master configuration."
        exit 0
    else
        log_message "VALIDATION FAILED: $validation_errors errors found in master configuration."
        echo "VALIDATION FAILED: $validation_errors errors found. Check log at $VALIDATION_LOG for details."
        exit 1
    fi
}

# Start the validation
main_validation
