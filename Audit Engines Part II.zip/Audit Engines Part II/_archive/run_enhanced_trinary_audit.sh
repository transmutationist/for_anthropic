#!/bin/bash
#
# run_enhanced_trinary_audit.sh
#
# Executes the enhanced post-quantum trinary audit engine.
# This script ensures the audit is run from the correct context and provides clear feedback.

# Get the directory where the script is located
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" &>/dev/null && pwd)"

ENGINE_PATH="$SCRIPT_DIR/trinary_audit_engine.py"

if [ ! -f "$ENGINE_PATH" ]; then
    echo "❌ ERROR: Audit engine not found at $ENGINE_PATH"
    exit 1
fi

echo "🌌 Engaging Enhanced Post-Quantum Trinary Audit Engine..."

# Execute the Python script
python3 "$ENGINE_PATH"

AUDIT_EXIT_CODE=$?

if [ $AUDIT_EXIT_CODE -eq 0 ]; then
    echo "✅ Audit complete. Report generated successfully."
else
    echo "❌ ERROR: Trinary audit failed with exit code $AUDIT_EXIT_CODE."
fi

exit $AUDIT_EXIT_CODE
