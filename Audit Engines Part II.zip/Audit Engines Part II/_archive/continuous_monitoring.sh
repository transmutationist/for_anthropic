#!/bin/bash
# Continuous Monitoring for ZEDEC System

echo "🔂 Launching Continuous Monitoring for ZEDEC System..."

# Monitor for new files and scripts
monitor_directory() {
  local dir_to_monitor="$1"
  echo "👀 Monitoring directory: $dir_to_monitor"
  while true; do
    inotifywait -r -e create,modify "$dir_to_monitor" | while read path action file; do
      echo "🆕 Detected change in $file at $path"
      # Trigger reaudit on file change
      echo "🔁 Triggering reaudit due to file change"
      touch /tmp/zedec_reaudit_trigger
    done
    sleep 10
  done
}

# Monitor ZEDEC directories
monitor_directory "/Users/36n9/ZEDEI" &
monitor_directory "/Users/36n9/CascadeProjects" &

# Implement Maybe deferral logic
echo "🕒 Implementing Maybe Deferral Logic..."
# Placeholder for Maybe deferral logic
# This will be expanded to handle deferring 'Maybe' audit items by 9, 81, 729 cycles, etc.

# Background loop to monitor system states and trigger re-audits on change
echo "🔂 Launching audit watchdog..."
nohup bash -c '
  while true; do
    if [ -f "/tmp/zedec_reaudit_trigger" ]; then
      echo "🔁 Reaudit triggered by system state change."
      bash "/Users/36n9/CascadeProjects/AUDIT_ENGINES/curzi_zedai_audit_launcher.sh"
      rm /tmp/zedec_reaudit_trigger
    fi
    sleep 15
  done
' &

echo "✅ Continuous Monitoring and Audit Watchdog Active"
