# Represents the 'Mind' and 'Digital Hardware' aspect of the system.

class DigitalHardwareInterface:
    """Simulated interface for the 'digital hardware' processing logical data."""
    def __init__(self):
        self.frequency = 144000
        self.paradox_count = 0

    def update_metrics(self, frequency: int, paradox_count: int):
        self.frequency = frequency
        self.paradox_count = paradox_count

class ElectromagneticField:
    """Manages the quantitative, logical state of the system."""
    def __init__(self):
        self.hardware = DigitalHardwareInterface()

    def get_state(self):
        return {'frequency': self.hardware.frequency, 'paradox_count': self.hardware.paradox_count}
