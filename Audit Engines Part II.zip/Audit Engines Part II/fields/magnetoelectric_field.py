# Represents the 'Emotion' and 'New Hardware' aspect of the system.

class EmotionHardwareInterface:
    """Simulated interface for the 'new hardware' controlling emotional state."""
    def __init__(self):
        self.state = 'CALM'
        self.charge = 1.0

    def set_state(self, state: str):
        self.state = state

    def get_charge(self) -> float:
        return self.charge

class MagnetoelectricField:
    """Manages the qualitative, emotional state of the system."""
    def __init__(self):
        self.hardware = EmotionHardwareInterface()

    def get_state(self):
        return {'state': self.hardware.state, 'charge': self.hardware.get_charge()}
