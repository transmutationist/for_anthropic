#!/usr/bin/env python3
"""
CURZI-ZEDEI Audit Engine – Layer 3 Validator (Deep Layer)
Validates the integrity of the ZedecAuditKernel itself.
"""

import json
import argparse
import logging
import os
import sys
import datetime
import hashlib
from typing import List, Dict

# Dynamically add the parent directory to the path to find the kernel
AUDIT_ENGINES_DIR = os.path.abspath(os.path.join(os.path.dirname(__file__), '..', '..'))
if AUDIT_ENGINES_DIR not in sys.path:
    sys.path.append(AUDIT_ENGINES_DIR)

from zedec_audit_kernel import ZedecAuditKernel

FINDINGS_FILE = "/tmp/curzi_findings.json"

class DeepValidator:
    """Validates core kernel integrity."""

    def __init__(self, kernel, meta_self):
        self.kernel = kernel
        self.meta_self = meta_self
        self.findings = []

    def validate_kernel_integrity(self):
        """Performs a hash check on the kernel file."""
        logging.info("Performing kernel integrity validation...")
        kernel_path = os.path.join(AUDIT_ENGINES_DIR, 'zedec_audit_kernel.py')
        expected_hash = self.kernel.get_system_config('kernel_integrity_hash')

        if not expected_hash:
            self._add_finding("meta_kernel_hash_missing", "Configuration for kernel hash is missing.", "Critical")
            return

        try:
            with open(kernel_path, 'rb') as f:
                kernel_bytes = f.read()
            current_hash = hashlib.sha256(kernel_bytes).hexdigest()

            if current_hash != expected_hash:
                message = f"Kernel integrity mismatch. Expected {expected_hash[:10]}..., got {current_hash[:10]}..."
                self._add_finding("meta_kernel_tampered", message, "Critical")
            else:
                logging.info(f"Kernel integrity verified. Hash: {current_hash[:10]}...")

        except FileNotFoundError:
            self._add_finding("meta_kernel_file_missing", f"Kernel file not found at {kernel_path}", "Critical")

    def _add_finding(self, finding_type: str, message: str, severity: str):
        finding = self.kernel.create_finding(
            finding_id=f"{finding_type}-{datetime.datetime.utcnow().timestamp()}",
            finding_type=finding_type,
            message=message,
            severity=severity,
            layer='layer3'
        )
        self.findings.append(finding)

def load_findings() -> List[Dict]:
    if not os.path.exists(FINDINGS_FILE):
        return []
    try:
        with open(FINDINGS_FILE, "r") as f:
            return json.load(f)
    except (FileNotFoundError, json.JSONDecodeError):
        return []

def save_findings(data: List[Dict]):
    with open(FINDINGS_FILE, "w") as f:
        json.dump(data, f, indent=2)

def main():
    parser = argparse.ArgumentParser(description="CURZI-ZEDEI Layer 3 Deep Validator")
    parser.add_argument("--loglevel", default="info")
    args = parser.parse_args()
    logging.basicConfig(level=getattr(logging, args.loglevel.upper(), logging.INFO), format="[L3-VALIDATOR] %(message)s")

    kernel = ZedecAuditKernel(base_dir=AUDIT_ENGINES_DIR, loglevel=args.loglevel)
    # Note: The registry uses 'cz_layer3_validator.py', so we use that for the lookup.
    script_name = 'cz_layer3_validator.py'
    meta_self = kernel.get_meta(script_name)

    if not meta_self:
        logging.error(f"Could not retrieve metadata for {script_name}. Aborting.")
        return

    logging.info(f"🛡️  Starting L3 Deep Validation as Glyph '{meta_self.get('glyph')}'...")

    validator = DeepValidator(kernel, meta_self)
    validator.validate_kernel_integrity()

    existing_findings = load_findings()
    all_findings = existing_findings + validator.findings
    save_findings(all_findings)

    logging.info(f"✅ L3 Deep Validation complete. {len(validator.findings)} new findings generated.")

if __name__ == "__main__":
    main()
