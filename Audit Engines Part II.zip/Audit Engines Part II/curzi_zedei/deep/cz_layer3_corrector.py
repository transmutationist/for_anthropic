#!/usr/bin/env python3
"""
CURZI-ZEDEI Audit Engine – Layer 3 Corrector (Deep Layer)
Identifies and reports on idle or non-responsive audit components.
"""

import json
import argparse
import logging
import os
import sys
import datetime
from typing import List, Dict

# Dynamically add the parent directory to the path to find the kernel
AUDIT_ENGINES_DIR = os.path.abspath(os.path.join(os.path.dirname(__file__), '..', '..'))
if AUDIT_ENGINES_DIR not in sys.path:
    sys.path.append(AUDIT_ENGINES_DIR)

from zedec_audit_kernel import ZedecAuditKernel

FINDINGS_FILE = "/tmp/curzi_findings.json"
HEALING_LOG_FILE = "/tmp/curzi_healing_log.json"

class DeepCorrector:
    """Corrects idle circuits by flagging inactive components."""

    def __init__(self, kernel, meta_self):
        self.kernel = kernel
        self.meta_self = meta_self
        self.healing_actions = []

    def check_for_idle_circuits(self, findings: List[Dict]):
        """Analyzes findings to identify audit scripts that are not reporting."""
        logging.info("Checking for idle audit circuits...")
        active_scripts = {finding.get('meta', {}).get('script_name') for finding in findings}
        all_scripts = self.kernel.get_all_script_names()

        idle_scripts = set(all_scripts) - active_scripts

        for script_name in idle_scripts:
            # Avoid flagging controllers or the launcher itself as idle in this context
            if 'controller' in script_name or 'launcher' in script_name or 'deep' in script_name:
                continue

            message = f"Audit component '{script_name}' has not reported any findings. Circuit may be idle or disconnected."
            self._add_healing_action("idle_circuit_detected", script_name, message, "High")

    def _add_healing_action(self, action_type: str, target: str, message: str, severity: str):
        action = {
            'timestamp': datetime.datetime.utcnow().isoformat(),
            'healer_glyph': self.meta_self.get('glyph'),
            'healer_script': self.meta_self.get('script_name'),
            'action_type': action_type,
            'target': target,
            'message': message,
            'severity': severity,
            'status': 'recommended'
        }
        self.healing_actions.append(action)
        logging.warning(f"Healing recommended for {target}: {message}")

def load_findings() -> List[Dict]:
    if not os.path.exists(FINDINGS_FILE):
        return []
    try:
        with open(FINDINGS_FILE, "r") as f:
            return json.load(f)
    except (FileNotFoundError, json.JSONDecodeError):
        return []

def save_healing_log(data: List[Dict]):
    existing_logs = []
    if os.path.exists(HEALING_LOG_FILE):
        try:
            with open(HEALING_LOG_FILE, "r") as f:
                existing_logs = json.load(f)
        except (FileNotFoundError, json.JSONDecodeError):
            pass # Start fresh if log is corrupted
    
    all_logs = existing_logs + data
    with open(HEALING_LOG_FILE, "w") as f:
        json.dump(all_logs, f, indent=2)

def main():
    parser = argparse.ArgumentParser(description="CURZI-ZEDEI Layer 3 Deep Corrector")
    parser.add_argument("--loglevel", default="info")
    args = parser.parse_args()
    logging.basicConfig(level=getattr(logging, args.loglevel.upper(), logging.INFO), format="[L3-CORRECTOR] %(message)s")

    kernel = ZedecAuditKernel(base_dir=AUDIT_ENGINES_DIR, loglevel=args.loglevel)
    script_name = 'cz_layer3_corrector.py'
    meta_self = kernel.get_meta(script_name)

    if not meta_self:
        logging.error(f"Could not retrieve metadata for {script_name}. Aborting.")
        return

    logging.info(f"⚡ Starting L3 Deep Correction as Glyph '{meta_self.get('glyph')}'...")

    findings = load_findings()
    corrector = DeepCorrector(kernel, meta_self)
    corrector.check_for_idle_circuits(findings)

    if corrector.healing_actions:
        save_healing_log(corrector.healing_actions)
        logging.info(f"✅ L3 Deep Correction complete. {len(corrector.healing_actions)} healing actions logged.")
    else:
        logging.info("✅ L3 Deep Correction complete. All circuits appear active.")

if __name__ == "__main__":
    main()
