#!/usr/bin/env python3
"""
CURZI-ZEDEI Audit Engine – Layer 3 Reporter (Deep Layer)
Generates a meta-report on the health and status of the entire audit engine.
"""

import json
import argparse
import logging
import os
import sys
import datetime
from typing import List, Dict

# Dynamically add the parent directory to the path to find the kernel
AUDIT_ENGINES_DIR = os.path.abspath(os.path.join(os.path.dirname(__file__), '..', '..'))
if AUDIT_ENGINES_DIR not in sys.path:
    sys.path.append(AUDIT_ENGINES_DIR)

from zedec_audit_kernel import ZedecAuditKernel

FINDINGS_FILE = "/tmp/curzi_findings.json"
HEALING_LOG_FILE = "/tmp/curzi_healing_log.json"

class DeepReporter:
    """Generates a summary report of the audit engine's state."""

    def __init__(self, kernel, meta_self):
        self.kernel = kernel
        self.meta_self = meta_self

    def generate_report(self, findings: List[Dict], healing_logs: List[Dict], output_format: str):
        """Generates and prints a report based on all collected data."""
        logging.info("Generating L3 Deep Report...")

        report = self._build_report_structure(findings, healing_logs)

        if output_format == 'json':
            print(json.dumps(report, indent=2))
        else:
            self._print_summary_report(report)

    def _build_report_structure(self, findings: List[Dict], healing_logs: List[Dict]) -> Dict:
        """Constructs the report dictionary."""
        summary = {
            'total_findings': len(findings),
            'total_healing_actions': len(healing_logs),
            'findings_by_severity': self._summarize_by_key(findings, 'severity'),
            'findings_by_layer': self._summarize_by_key(findings, 'layer'),
            'healing_actions_by_severity': self._summarize_by_key(healing_logs, 'severity'),
        }

        report = {
            'report_generated_utc': datetime.datetime.utcnow().isoformat(),
            'reporter_glyph': self.meta_self.get('glyph'),
            'reporter_meaning': self.meta_self.get('meaning'),
            'engine_health_summary': summary,
            'deep_layer_findings': [f for f in findings if f.get('layer') == 'layer3'],
            'deep_layer_healing_actions': [h for h in healing_logs if h.get('healer_glyph') == self.kernel.get_meta('cz_layer3_corrector.py').get('glyph')],
            'full_findings': findings if self.kernel.loglevel.upper() == 'DEBUG' else 'Set loglevel to debug for full list',
            'full_healing_log': healing_logs if self.kernel.loglevel.upper() == 'DEBUG' else 'Set loglevel to debug for full list',
        }
        return report

    def _summarize_by_key(self, items: List[Dict], key: str) -> Dict[str, int]:
        summary = {}
        for item in items:
            value = item.get(key, 'Unknown')
            summary[value] = summary.get(value, 0) + 1
        return summary

    def _print_summary_report(self, report: Dict):
        """Prints a human-readable summary to the console."""
        summary = report['engine_health_summary']
        print("\n--- CURZI-ZEDEI AUDIT ENGINE META-REPORT ---")
        print(f"Report Time (UTC): {report['report_generated_utc']}")
        print(f"Reporter Glyph '{report['reporter_glyph']}': {report['reporter_meaning']}")
        print("--------------------------------------------")
        print(f"Total Findings: {summary['total_findings']}")
        print(f"  By Severity: {summary['findings_by_severity']}")
        print(f"  By Layer: {summary['findings_by_layer']}")
        print(f"Total Healing Actions: {summary['total_healing_actions']}")
        print(f"  By Severity: {summary['healing_actions_by_severity']}")
        print("--------------------------------------------")
        if report['deep_layer_findings']:
            print("\nDeep Layer Findings (Kernel Health):")
            for f in report['deep_layer_findings']:
                print(f"  - [{f.get('severity')}] {f.get('message')}")
        if report['deep_layer_healing_actions']:
            print("\nDeep Layer Healing Recommendations (Circuit Health):")
            for h in report['deep_layer_healing_actions']:
                print(f"  - [{h.get('severity')}] {h.get('message')}")
        print("\n--- END OF REPORT ---")

def load_data(file_path: str) -> List[Dict]:
    if not os.path.exists(file_path):
        return []
    try:
        with open(file_path, "r") as f:
            return json.load(f)
    except (FileNotFoundError, json.JSONDecodeError):
        return []

def main():
    parser = argparse.ArgumentParser(description="CURZI-ZEDEI Layer 3 Deep Reporter")
    parser.add_argument("--loglevel", default="info")
    parser.add_argument("--format", default="summary", choices=['summary', 'json'])
    args = parser.parse_args()
    logging.basicConfig(level=getattr(logging, args.loglevel.upper(), logging.INFO), format="[L3-REPORTER] %(message)s")

    kernel = ZedecAuditKernel(base_dir=AUDIT_ENGINES_DIR, loglevel=args.loglevel)
    script_name = 'cz_layer3_reporter.py'
    meta_self = kernel.get_meta(script_name)

    if not meta_self:
        logging.error(f"Could not retrieve metadata for {script_name}. Aborting.")
        return

    logging.info(f"🌳 Generating L3 Deep Report as Glyph '{meta_self.get('glyph')}'...")

    findings = load_data(FINDINGS_FILE)
    healing_logs = load_data(HEALING_LOG_FILE)
    
    reporter = DeepReporter(kernel, meta_self)
    reporter.generate_report(findings, healing_logs, args.format)

    logging.info("✅ L3 Deep Report generation complete.")

if __name__ == "__main__":
    main()
