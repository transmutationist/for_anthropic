#!/usr/bin/env python3
"""
CURZI-ZEDEI Audit Engine – Layer 2 Reporter (Kernel-Aware)
Quantum meta-dimensional reporter, signed by its glyphic identity.
"""

import json
import argparse
import logging
import datetime
import collections
import hashlib
import os
import sys
from typing import Dict, List, Any, Optional

# Dynamically add the parent directory to the path to find the kernel
AUDIT_ENGINES_DIR = os.path.abspath(os.path.join(os.path.dirname(__file__), '..', '..'))
if AUDIT_ENGINES_DIR not in sys.path:
    sys.path.append(AUDIT_ENGINES_DIR)

from zedec_audit_kernel import ZedecAuditKernel

# Configuration
FINDINGS_FILE = "/tmp/curzi_findings.json"
META_REPORT_FILE = "/tmp/curzi_layer2_meta_report.json"
TESLA_PATTERN = [3, 6, 9]

class MetaDimensionalReporter:
    """Meta-dimensional reporter for Layer 2 comprehensive analysis."""

    def __init__(self, kernel, meta_self):
        self.kernel = kernel
        self.meta_self = meta_self

    def generate_comprehensive_meta_report(self, findings: List[Dict]) -> Dict[str, Any]:
        """Generate comprehensive meta-dimensional report."""
        timestamp = datetime.datetime.utcnow().isoformat()
        layer2_findings = [f for f in findings if f.get("layer") == "layer2" or f.get("type", "").startswith("meta_")]

        finding_categories = self._categorize_findings(layer2_findings)
        tesla_analysis = self._perform_tesla_pattern_analysis(layer2_findings)
        healer_analysis = self._analyze_healers(layer2_findings)
        meta_signature = self._generate_meta_dimensional_signature(layer2_findings)

        comprehensive_report = {
            "timestamp": timestamp,
            "report_type": "META_DIMENSIONAL_LAYER2_COMPREHENSIVE",
            "reporter_glyph": self.meta_self.get("glyph"),
            "reporter_phase": self.meta_self.get("phase"),
            "meta_dimensional_signature": meta_signature,
            "healer_analysis": healer_analysis,
            "tesla_pattern_analysis": tesla_analysis,
            "finding_categories": finding_categories,
            "layer2_summary": {
                "total_meta_findings": len(layer2_findings),
                "findings_by_healer": healer_analysis.get("findings_by_healer"),
            },
            "raw_findings_count": len(findings)
        }

        self._save_meta_report(comprehensive_report)
        return comprehensive_report

    def _categorize_findings(self, findings: List[Dict]) -> Dict[str, Any]:
        by_severity = collections.Counter(f.get("severity") for f in findings)
        by_type = collections.Counter(f.get("type") for f in findings)
        return {"by_severity": by_severity, "by_type": by_type}

    def _perform_tesla_pattern_analysis(self, findings: List[Dict]) -> Dict[str, Any]:
        tesla_findings = [f for i, f in enumerate(findings) if (i + 1) % 3 == 0]
        tesla_severity = collections.Counter(f.get("severity") for f in tesla_findings)
        return {
            "tesla_positions_detected": len(tesla_findings),
            "tesla_severity_distribution": dict(tesla_severity)
        }

    def _analyze_healers(self, findings: List[Dict]) -> Dict[str, Any]:
        healed_findings = [f for f in findings if "healer_glyph" in f]
        by_healer = collections.Counter(f.get("healer_glyph") for f in healed_findings)
        return {
            "total_healed_findings": len(healed_findings),
            "findings_by_healer": dict(by_healer)
        }

    def _generate_meta_dimensional_signature(self, findings: List[Dict]) -> str:
        signature_data = {
            "timestamp": datetime.datetime.utcnow().isoformat(),
            "total_findings": len(findings),
            "reporter_glyph": self.meta_self.get("glyph"),
            "critical_count": len([f for f in findings if f.get("severity") == "Critical"])
        }
        signature_str = json.dumps(signature_data, sort_keys=True).encode()
        return hashlib.sha256(signature_str).hexdigest()

    def _save_meta_report(self, report: Dict[str, Any]):
        try:
            with open(META_REPORT_FILE, "w") as f:
                json.dump(report, f, indent=2)
        except Exception as e:
            logging.error(f"Failed to save meta-dimensional report: {e}")

def load_findings() -> List[Dict]:
    try:
        with open(FINDINGS_FILE, "r") as f:
            return json.load(f)
    except (FileNotFoundError, json.JSONDecodeError):
        logging.error(f"Could not load or parse findings from {FINDINGS_FILE}")
        return []

def main():
    parser = argparse.ArgumentParser(description="CURZI-ZEDEI Layer 2 Meta-Dimensional Reporter")
    parser.add_argument("--loglevel", default="info", choices=["debug", "info", "warning", "error"])
    parser.add_argument("--format", default="summary", choices=["summary", "detailed", "full"])
    parser.add_argument("--cycle", type=int, default=1, help="Execution cycle number from the launcher.")
    parser.add_argument("--rodin", type=int, default=1, help="Rodin sequence position from the launcher.")
    parser.add_argument("--tesla", type=int, default=3, help="Tesla frequency (3, 6, 9) from the launcher.")
    args = parser.parse_args()
    logging.basicConfig(level=getattr(logging, args.loglevel.upper(), logging.INFO), format="[L2-REPORTER] %(message)s")

    kernel = ZedecAuditKernel(base_dir=AUDIT_ENGINES_DIR, loglevel=args.loglevel)
    script_name = os.path.basename(__file__)
    meta_self = kernel.get_meta(script_name)

    if not meta_self:
        logging.error(f"Could not retrieve metadata for {script_name}. Aborting.")
        return

    logging.info(f"🌌 Starting L2 Reporting as Glyph '{meta_self.get('glyph')}'...")

    reporter = MetaDimensionalReporter(kernel, meta_self)
    all_findings = load_findings()
    logging.info(f"🔍 Loaded {len(all_findings)} total findings for reporting.")

    report = reporter.generate_comprehensive_meta_report(all_findings)

    if args.format == "full":
        print(json.dumps(report, indent=2))
    elif args.format == "detailed":
        detailed_report = {
            "reporter_glyph": report.get("reporter_glyph"),
            "meta_dimensional_signature": report.get("meta_dimensional_signature"),
            "layer2_summary": report.get("layer2_summary"),
            "finding_categories": report.get("finding_categories")
        }
        print(json.dumps(detailed_report, indent=2))
    else: # summary
        summary = {
            "reporter": report.get("reporter_glyph"),
            "total_meta_findings": report.get("layer2_summary", {}).get("total_meta_findings"),
            "findings_by_severity": dict(report.get("finding_categories", {}).get("by_severity", {})),
            "findings_by_healer": report.get("healer_analysis", {}).get("findings_by_healer")
        }
        print(json.dumps(summary, indent=2))

    logging.info(f"📊 Report signed by {meta_self.get('glyph')} saved to {META_REPORT_FILE}")

if __name__ == "__main__":
    main()
