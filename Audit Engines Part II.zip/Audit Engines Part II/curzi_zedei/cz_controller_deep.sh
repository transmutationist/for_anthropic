#!/bin/bash
# CURZI-ZEDEI Audit Engine - Deep Layer Controller
# Orchestrates the execution of the Layer 3 (Deep) audit scripts.

set -e

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
DEEP_DIR="$SCRIPT_DIR/deep"
LOG_LEVEL=${1:-"info"}

echo "--- [CONTROLLER-DEEP] INITIATING DEEP AUDIT SEQUENCE ---"

# 1. Deep Validator - Check kernel integrity
echo "--- [CONTROLLER-DEEP] Running L3 Deep Validator ---"
python3 "$DEEP_DIR/cz_layer3_validator.py" --loglevel "$LOG_LEVEL"

# 2. Deep Corrector - Check for idle circuits in the engine
echo "--- [CONTROLLER-DEEP] Running L3 Deep Corrector ---"
python3 "$DEEP_DIR/cz_layer3_corrector.py" --loglevel "$LOG_LEVEL"

# 3. Deep Reporter - Generate meta-report on engine health
echo "--- [CONTROLLER-DEEP] Running L3 Deep Reporter ---"
python3 "$DEEP_DIR/cz_layer3_reporter.py" --loglevel "$LOG_LEVEL" --format summary

echo "--- [CONTROLLER-DEEP] DEEP AUDIT SEQUENCE COMPLETE ---"
