#!/bin/bash
# CURZI-ZEDEI Audit Engine - Mid Layer Controller
# Orchestrates the execution of the Layer 2 (Mid) audit scripts.

set -e

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
MID_DIR="$SCRIPT_DIR/mid"
LOG_LEVEL=${1:-"info"}

echo "--- [CONTROLLER-MID] INITIATING MID-LEVEL AUDIT SEQUENCE ---"

# 1. Mid Validator
echo "--- [CONTROLLER-MID] Running L2 Mid Validator ---"
python3 "$MID_DIR/cz_layer2_validator.py" --loglevel "$LOG_LEVEL"

# 2. Mid Corrector
echo "--- [CONTROLLER-MID] Running L2 Mid Corrector ---"
python3 "$MID_DIR/cz_layer2_corrector.py" --loglevel "$LOG_LEVEL"

# 3. Mid Reporter
echo "--- [CONTROLLER-MID] Running L2 Mid Reporter ---"
python3 "$MID_DIR/cz_layer2_reporter.py" --loglevel "$LOG_LEVEL" --format summary

echo "--- [CONTROLLER-MID] MID-LEVEL AUDIT SEQUENCE COMPLETE ---"
