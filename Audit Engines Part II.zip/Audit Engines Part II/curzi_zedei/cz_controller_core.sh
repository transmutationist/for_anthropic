#!/bin/bash
# CURZI-ZEDEI Audit Engine - Core Layer Controller
# Orchestrates the execution of the Layer 1 (Core) audit scripts.

set -e

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
CORE_DIR="$SCRIPT_DIR/core"
LOG_LEVEL=${1:-"info"}

echo "--- [CONTROLLER-CORE] INITIATING CORE AUDIT SEQUENCE ---"

# 1. Core Validator
echo "--- [CONTROLLER-CORE] Running L1 Core Validator ---"
python3 "$CORE_DIR/cz_layer1_validator.py" --loglevel "$LOG_LEVEL"

# 2. Core Reporter
echo "--- [CONTROLLER-CORE] Running L1 Core Reporter ---"
python3 "$CORE_DIR/cz_layer1_reporter.py" --loglevel "$LOG_LEVEL" --format summary

echo "--- [CONTROLLER-CORE] CORE AUDIT SEQUENCE COMPLETE ---"
