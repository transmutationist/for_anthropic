#!/bin/bash
# CURZI-ZEDEI Audit Engine - Omni Layer Controller
# Orchestrates the execution of all audit layers.

set -e

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
LOG_LEVEL=${1:-"info"}

echo "--- [CONTROLLER-OMNI] INITIATING FULL NINARY AUDIT CYCLE ---"

# Clear previous run's temporary files for a clean slate
rm -f /tmp/curzi_findings.json /tmp/curzi_quantum_state.json /tmp/curzi_healing_log.json
echo "--- [CONTROLLER-OMNI] Cleared temporary files."

# Execute controllers for each layer in sequence

echo "
### EXECUTING CORE LAYER ###"
"$SCRIPT_DIR/cz_controller_core.sh" "$LOG_LEVEL"

echo "
### EXECUTING MID LAYER ###"
"$SCRIPT_DIR/cz_controller_mid.sh" "$LOG_LEVEL"

echo "
### EXECUTING DEEP LAYER ###"
"$SCRIPT_DIR/cz_controller_deep.sh" "$LOG_LEVEL"

echo "
--- [CONTROLLER-OMNI] FULL NINARY AUDIT CYCLE COMPLETE ---"
