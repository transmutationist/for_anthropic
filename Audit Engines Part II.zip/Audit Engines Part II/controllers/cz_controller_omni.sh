#!/bin/bash
# CURZI-ZEDEI Omni Controller (Layer 3)
# Executes validator → corrector → reporter for omni layer in sequence.

set -e

DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"
BASE="${DIR}/.."

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

echo -e "${BLUE}🌀 Executing Omni Layer (Layer 3) Audit Sequence${NC}"

echo -e "${BLUE}🔍 Running Validator...${NC}"
if ! python3 "$BASE/curzi_zedei/omni/cz_layer3_validator.py" "$@"; then
  echo -e "${RED}❌ Validator failed${NC}" >&2
  exit 1
fi

echo -e "${BLUE}🔧 Running Corrector...${NC}"
if ! python3 "$BASE/curzi_zedei/omni/cz_layer3_corrector.py" "$@"; then
  echo -e "${RED}❌ Corrector failed${NC}" >&2
  exit 1
fi

echo -e "${BLUE}📋 Running Reporter...${NC}"
if ! python3 "$BASE/curzi_zedei/omni/cz_layer3_reporter.py" "$@"; then
  echo -e "${RED}❌ Reporter failed${NC}" >&2
  exit 1
fi

echo -e "${GREEN}✅ Omni Layer (Layer 3) Audit Sequence Completed Successfully${NC}"
exit 0
