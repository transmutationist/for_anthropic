#!/bin/bash
# CURZI-ZEDEI Core Controller (Layer 1)
# Executes validator → corrector → reporter for core layer in sequence.

set -e

DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"
BASE="${DIR}/.."

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

echo -e "${BLUE}🌀 Executing Core Layer (Layer 1) Audit Sequence${NC}"

echo -e "${BLUE}🔍 Running Validator...${NC}"
if ! python3 "$BASE/curzi_zedei/core/cz_layer1_validator.py" "$@"; then
  echo -e "${RED}❌ Validator failed${NC}" >&2
  exit 1
fi

echo -e "${BLUE}🔧 Running Corrector...${NC}"
if ! python3 "$BASE/curzi_zedei/core/cz_layer1_corrector.py" "$@"; then
  echo -e "${RED}❌ Corrector failed${NC}" >&2
  exit 1
fi

echo -e "${BLUE}📋 Running Reporter...${NC}"
if ! python3 "$BASE/curzi_zedei/core/cz_layer1_reporter.py" "$@"; then
  echo -e "${RED}❌ Reporter failed${NC}" >&2
  exit 1
fi

echo -e "${GREEN}✅ Core Layer (Layer 1) Audit Sequence Completed Successfully${NC}"
exit 0
