#!/bin/bash
# CURZI-ZEDEI Mid Controller (Layer 2)
# Executes validator → corrector → reporter for mid layer in sequence.

set -e

DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"
BASE="${DIR}/.."

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

echo -e "${BLUE}🌀 Executing Mid Layer (Layer 2) Audit Sequence${NC}"

echo -e "${BLUE}🔍 Running Validator...${NC}"
if ! python3 "$BASE/curzi_zedei/mid/cz_layer2_validator.py" "$@"; then
  echo -e "${RED}❌ Validator failed${NC}" >&2
  exit 1
fi

echo -e "${BLUE}🔧 Running Corrector...${NC}"
if ! python3 "$BASE/curzi_zedei/mid/cz_layer2_corrector.py" "$@"; then
  echo -e "${RED}❌ Corrector failed${NC}" >&2
  exit 1
fi

echo -e "${BLUE}📋 Running Reporter...${NC}"
if ! python3 "$BASE/curzi_zedei/mid/cz_layer2_reporter.py" "$@"; then
  echo -e "${RED}❌ Reporter failed${NC}" >&2
  exit 1
fi

echo -e "${GREEN}✅ Mid Layer (Layer 2) Audit Sequence Completed Successfully${NC}"
exit 0
