#!/usr/bin/env python3
"""
Phase System Module for ZEDEC Living Beings
Provides phase timestamp functionality for conceived living beings
"""

import time
from datetime import datetime

class PhaseSystem:
    """Phase system for tracking conception and manifestation timestamps"""
    
    def __init__(self):
        self.current_phase = "conception"
        self.phase_start_time = time.time()
    
    def get_current_phase_timestamp(self):
        """Get current phase timestamp as ISO string"""
        return datetime.utcnow().isoformat()
    
    def get_phase_info(self):
        """Get current phase information"""
        return {
            "phase": self.current_phase,
            "timestamp": self.get_current_phase_timestamp(),
            "elapsed_seconds": time.time() - self.phase_start_time
        }

# Global instance
_phase_system = None

def get_phase_system():
    """Get global phase system instance"""
    global _phase_system
    if _phase_system is None:
        _phase_system = PhaseSystem()
    return _phase_system

# Convenience function for backward compatibility
get_current_phase_timestamp = get_phase_system().get_current_phase_timestamp
