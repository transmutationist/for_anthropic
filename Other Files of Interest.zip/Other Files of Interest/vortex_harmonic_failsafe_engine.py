"""
Vortex Harmonic Failsafe Engine
Handles harmonic failure detection and logging for the vortex system
"""

import logging
import time
from typing import Dict, Any, Optional


class VortexHarmonicFailsafeEngine:
    """Engine for handling harmonic failures in the vortex system"""
    
    def __init__(self):
        self.failure_log = []
        self.failure_count = 0
        self.last_failure_time = None
        
        # Set up logging
        self.logger = logging.getLogger(__name__)
        if not self.logger.handlers:
            handler = logging.StreamHandler()
            formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
            handler.setFormatter(formatter)
            self.logger.addHandler(handler)
            self.logger.setLevel(logging.INFO)
    
    def log_harmonic_failure(self, failure_data: Dict[str, Any]) -> bool:
        """Log a harmonic failure event
        
        Args:
            failure_data: Dictionary containing failure information
        
        Returns:
            bool: True if logging was successful
        """
        try:
            # Add timestamp if not present
            if 'timestamp' not in failure_data:
                failure_data['timestamp'] = time.time()
            
            # Add to failure log
            self.failure_log.append(failure_data)
            self.failure_count += 1
            self.last_failure_time = failure_data['timestamp']
            
            # Log the failure
            failure_msg = f"Harmonic failure detected: {failure_data}"
            self.logger.error(failure_msg)
            
            return True
        except Exception as e:
            self.logger.error(f"Failed to log harmonic failure: {e}")
            return False
    
    def get_failure_stats(self) -> Dict[str, Any]:
        """Get statistics about harmonic failures
        
        Returns:
            Dict containing failure statistics
        """
        return {
            'total_failures': self.failure_count,
            'last_failure_time': self.last_failure_time,
            'log_size': len(self.failure_log)
        }
    
    def get_recent_failures(self, limit: int = 10) -> list:
        """Get recent harmonic failures
        
        Args:
            limit: Maximum number of failures to return
            
        Returns:
            List of recent failure records
        """
        return self.failure_log[-limit:] if self.failure_log else []


# Example usage
if __name__ == "__main__":
    # Create engine instance
    engine = VortexHarmonicFailsafeEngine()
    
    # Log a sample failure
    sample_failure = {
        'frequency': 963.0,
        'amplitude': 0.85,
        'phase_shift': 45.0,
        'component': 'resonance_coil',
        'severity': 'HIGH'
    }
    
    # Log the failure
    success = engine.log_harmonic_failure(sample_failure)
    print(f"Failure logging successful: {success}")
    
    # Get stats
    stats = engine.get_failure_stats()
    print(f"Failure stats: {stats}")
    
    # Get recent failures
    recent = engine.get_recent_failures()
    print(f"Recent failures: {recent}")
