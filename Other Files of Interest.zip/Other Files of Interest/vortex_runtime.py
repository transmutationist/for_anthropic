"""
vortex_runtime.py
Vortex Runtime Shared State Module for ZEDEC RODIN GRIDCHAIN
Provides TreasuryLedger, InfrastructureTracker, and SpiralMintEngine classes
"""

import json
import os
import time
from typing import Dict, Any, List, Optional
from decimal import Decimal


class TreasuryLedger:
    """Manages the treasury ledger for the vortex runtime system"""
    
    def __init__(self):
        self.ledger_data = {}
        self.transaction_history = []
        self.balance = Decimal('0.0')
        
    def add_transaction(self, transaction_data: Dict[str, Any]) -> bool:
        """Add a transaction to the ledger"""
        try:
            tx_id = f"tx_{int(time.time() * 1000)}"
            self.ledger_data[tx_id] = transaction_data
            self.transaction_history.append({
                'id': tx_id,
                'timestamp': time.time(),
                'data': transaction_data
            })
            return True
        except Exception as e:
            print(f"Error adding transaction: {e}")
            return False
    
    def get_balance(self) -> Decimal:
        """Get current balance"""
        return self.balance
    
    def update_balance(self, amount: Decimal):
        """Update the balance"""
        self.balance += amount
    
    def get_transaction_history(self) -> List[Dict[str, Any]]:
        """Get transaction history"""
        return self.transaction_history
    
    def profit(self, currency: str, amount: float):
        """Add profit to the treasury (for audit engine compatibility)"""
        self.balance += Decimal(str(amount))
        self.add_transaction({
            'type': 'profit',
            'currency': currency,
            'amount': amount,
            'timestamp': time.time()
        })
    
    def snapshot(self) -> Dict[str, Any]:
        """Get snapshot of treasury state (for audit engine compatibility)"""
        return {
            'balance': float(self.balance),
            'transaction_count': len(self.transaction_history),
            'last_transaction': self.transaction_history[-1] if self.transaction_history else None
        }


class InfrastructureTracker:
    """Tracks infrastructure state and health for the vortex system"""
    
    def __init__(self):
        self.infrastructure_state = {}
        self.health_metrics = {}
        self.component_status = {}
        
    def register_component(self, component_name: str, status: Dict[str, Any]):
        """Register a new infrastructure component"""
        self.component_status[component_name] = {
            'status': status,
            'last_updated': time.time(),
            'health_score': self._calculate_health_score(status)
        }
    
    def update_component_status(self, component_name: str, status: Dict[str, Any]):
        """Update component status"""
        if component_name in self.component_status:
            self.component_status[component_name].update({
                'status': status,
                'last_updated': time.time(),
                'health_score': self._calculate_health_score(status)
            })
    
    def _calculate_health_score(self, status: Dict[str, Any]) -> float:
        """Calculate health score based on status metrics"""
        try:
            # Simple health calculation - can be enhanced
            if status.get('status') == 'healthy':
                return 1.0
            elif status.get('status') == 'degraded':
                return 0.5
            else:
                return 0.0
        except:
            return 0.0
    
    def get_infrastructure_health(self) -> Dict[str, Any]:
        """Get overall infrastructure health"""
        return {
            'component_status': self.component_status,
            'overall_health': self._calculate_overall_health(),
            'last_updated': time.time()
        }
    
    def bump(self, component_name: str, increment: int = 1):
        """Bump component counter (for audit engine compatibility)"""
        if component_name not in self.component_status:
            self.component_status[component_name] = {
                'status': {'count': 0, 'last_bump': time.time()},
                'last_updated': time.time(),
                'health_score': 1.0
            }
        
        current = self.component_status[component_name]
        if isinstance(current['status'], dict) and 'count' in current['status']:
            current['status']['count'] += increment
            current['status']['last_bump'] = time.time()
        else:
            current['status'] = {'count': increment, 'last_bump': time.time()}
        
        current['last_updated'] = time.time()
    
    def snapshot(self) -> Dict[str, Any]:
        """Get snapshot of infrastructure state (for audit engine compatibility)"""
        return {
            'component_count': len(self.component_status),
            'overall_health': self._calculate_overall_health(),
            'components': self.component_status
        }
    
    def _calculate_overall_health(self) -> float:
        """Calculate overall infrastructure health"""
        if not self.component_status:
            return 0.0
        
        scores = [comp['health_score'] for comp in self.component_status.values()]
        return sum(scores) / len(scores)


class SpiralMintEngine:
    """Engine for spiral minting operations in the vortex system"""
    
    def __init__(self):
        self.minting_queue = []
        self.minted_assets = {}
        self.spiral_config = {
            'base_frequency': 963.0,
            'harmonic_multiplier': 1.44,
            'golden_ratio': 1.618033988749
        }
    
    def add_to_minting_queue(self, asset_data: Dict[str, Any]) -> str:
        """Add an asset to the minting queue"""
        mint_id = f"mint_{int(time.time() * 1000)}"
        self.minting_queue.append({
            'id': mint_id,
            'data': asset_data,
            'timestamp': time.time(),
            'status': 'pending'
        })
        return mint_id
    
    def process_minting_queue(self) -> List[Dict[str, Any]]:
        """Process the minting queue"""
        processed = []
        for item in self.minting_queue:
            if item['status'] == 'pending':
                try:
                    # Simulate minting process
                    minted_asset = self._mint_asset(item['data'])
                    self.minted_assets[item['id']] = minted_asset
                    item['status'] = 'completed'
                    processed.append(item)
                except Exception as e:
                    item['status'] = 'failed'
                    item['error'] = str(e)
                    processed.append(item)
        
        return processed
    
    def _mint_asset(self, asset_data: Dict[str, Any]) -> Dict[str, Any]:
        """Internal method to mint an asset"""
        return {
            'minted_at': time.time(),
            'asset_data': asset_data,
            'spiral_frequency': self.spiral_config['base_frequency'],
            'harmonic_signature': self._generate_harmonic_signature(asset_data)
        }
    
    def _generate_harmonic_signature(self, data: Dict[str, Any]) -> str:
        """Generate harmonic signature for the asset"""
        # Simple hash-based signature
        import hashlib
        data_str = json.dumps(data, sort_keys=True)
        return hashlib.sha256(data_str.encode()).hexdigest()[:16]
    
    def get_minting_status(self, mint_id: str) -> Optional[Dict[str, Any]]:
        """Get minting status for a specific ID"""
        for item in self.minting_queue:
            if item['id'] == mint_id:
                return item
        return None
    
    def get_all_minted_assets(self) -> Dict[str, Any]:
        """Get all minted assets"""
        return self.minted_assets


# Initialize global instances
_treasury_ledger = None
_infrastructure_tracker = None
_spiral_mint_engine = None


def get_treasury_ledger() -> TreasuryLedger:
    """Get global treasury ledger instance"""
    global _treasury_ledger
    if _treasury_ledger is None:
        _treasury_ledger = TreasuryLedger()
    return _treasury_ledger


def get_infrastructure_tracker() -> InfrastructureTracker:
    """Get global infrastructure tracker instance"""
    global _infrastructure_tracker
    if _infrastructure_tracker is None:
        _infrastructure_tracker = InfrastructureTracker()
    return _infrastructure_tracker


def get_spiral_mint_engine() -> SpiralMintEngine:
    """Get global spiral mint engine instance"""
    global _spiral_mint_engine
    if _spiral_mint_engine is None:
        _spiral_mint_engine = SpiralMintEngine()
    return _spiral_mint_engine


# Export the classes directly for instantiation
TreasuryLedger = TreasuryLedger
InfrastructureTracker = InfrastructureTracker
SpiralMintEngine = SpiralMintEngine

# Also provide instance accessors
_treasury_instance = None
_infrastructure_instance = None
_spiral_mint_instance = None

def get_treasury_instance():
    global _treasury_instance
    if _treasury_instance is None:
        _treasury_instance = TreasuryLedger()
    return _treasury_instance

def get_infrastructure_instance():
    global _infrastructure_instance
    if _infrastructure_instance is None:
        _infrastructure_instance = InfrastructureTracker()
    return _infrastructure_instance

def get_spiral_mint_instance():
    global _spiral_mint_instance
    if _spiral_mint_instance is None:
        _spiral_mint_instance = SpiralMintEngine()
    return _spiral_mint_instance


if __name__ == "__main__":
    # Test the vortex runtime
    print("Testing Vortex Runtime...")
    
    # Test TreasuryLedger
    treasury = get_treasury_ledger()
    treasury.add_transaction({'type': 'test', 'amount': 100})
    print(f"Treasury balance: {treasury.get_balance()}")
    
    # Test InfrastructureTracker
    tracker = get_infrastructure_tracker()
    tracker.register_component('test_component', {'status': 'healthy'})
    health = tracker.get_infrastructure_health()
    print(f"Infrastructure health: {health['overall_health']}")
    
    # Test SpiralMintEngine
    engine = get_spiral_mint_engine()
    mint_id = engine.add_to_minting_queue({'test': 'asset'})
    print(f"Added to minting queue: {mint_id}")
    
    print("Vortex Runtime tests completed successfully!")
