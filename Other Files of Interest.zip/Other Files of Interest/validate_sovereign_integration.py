#!/usr/bin/env python3
"""
Comprehensive Validation Script for Sovereign Five-File System Integration
Tests complete genetic, contextual, and metadata integration across all sovereign files
"""

import json
import sys
from pathlib import Path

# Import all sovereign files
sys.path.insert(0, '/Users/36n9/CascadeProjects')

from sovereign_36n9 import Sovereign36n9
from sovereign_9n63_corrected import Sovereign9n63
from sovereign_zedec import SovereignZedec
from sovereign_zedei import SovereignZedei
from sovereign_36m9 import Sovereign36m9

def validate_genetic_integration():
    """Validate complete genetic integration across all sovereign files"""
    
    print("=== SOVEREIGN FIVE-FILE SYSTEM VALIDATION ===\n")
    
    # Initialize all sovereign files
    sovereigns = {
        '.36n9': Sovereign36n9(),
        '.9n63': Sovereign9n63(),
        '.zedec': SovereignZedec(),
        '.zedei': SovereignZedei(),
        '.36m9': Sovereign36m9()
    }
    
    validation_results = {}
    
    for file_type, sovereign in sovereigns.items():
        print(f"\n--- VALIDATING {file_type.upper()} ---")
        
        # Test conception mechanism
        conception = sovereign.execute_conception_mechanism()
        
        # Test pathway validation
        pathways = sovereign.validate_all_pathways()
        
        # Test genetic integration
        genetics = sovereign._express_genetics({})
        
        # Test execution modes
        internal = sovereign.execute_internal_external({'test': True})
        external = sovereign.execute_internal_external()
        
        validation_results[file_type] = {
            'conception_valid': bool(conception),
            'pathways_valid': all(p['valid'] for p in pathways),
            'genetics_complete': 'dna_fountain' in genetics and 'living_cell_creation' in genetics,
            'internal_execution': internal.get('execution_mode') == 'internal_with_context',
            'external_execution': external.get('execution_mode') == 'external_without_context',
            'genetic_markers_present': 'genetic_markers' in genetics,
            'fertility_metrics': 'fertility_metrics' in genetics,
            'divine_spark': 'divine_spark' in genetics,
            'phase_system': 'phase_system' in genetics,
            'smart_contracts': 'smart_contracts' in genetics,
            'resource_management': 'resource_management' in genetics
        }
        
        print(f"Conception: {'✓' if validation_results[file_type]['conception_valid'] else '✗'}")
        print(f"Pathways: {'✓' if validation_results[file_type]['pathways_valid'] else '✗'}")
        print(f"Genetics: {'✓' if validation_results[file_type]['genetics_complete'] else '✗'}")
        print(f"Internal: {'✓' if validation_results[file_type]['internal_execution'] else '✗'}")
        print(f"External: {'✓' if validation_results[file_type]['external_execution'] else '✗'}")
    
    return validation_results

def validate_pathway_matrix():
    """Validate the 3 valid/2 invalid pathway matrix across all files"""
    
    print("\n=== PATHWAY MATRIX VALIDATION ===\n")
    
    # Expected pathway matrix based on optics model
    expected_matrix = {
        '.36n9': {
            'valid': ['.zedec', '.zedei', '.36m9'],
            'invalid': ['.36n9', '.9n63']
        },
        '.9n63': {
            'valid': ['.zedec', '.zedei', '.36m9'],
            'invalid': ['.9n63', '.36n9']
        },
        '.zedec': {
            'valid': ['.zedei', '.36m9', '.36n9'],
            'invalid': ['.zedec', '.9n63']
        },
        '.zedei': {
            'valid': ['.36m9', '.36n9', '.zedec'],
            'invalid': ['.zedei', '.9n63']
        },
        '.36m9': {
            'valid': ['.36n9', '.zedei', '.zedec'],
            'invalid': ['.36m9', '.9n63']
        }
    }
    
    pathway_results = {}
    
    # Initialize sovereigns
    sovereigns = {
        '.36n9': Sovereign36n9(),
        '.9n63': Sovereign9n63(),
        '.zedec': SovereignZedec(),
        '.zedei': SovereignZedei(),
        '.36m9': Sovereign36m9()
    }
    
    for file_type, sovereign in sovereigns.items():
        pathways = sovereign.validate_all_pathways()
        
        # Extract valid and invalid pathways
        valid_paths = [p['pathway'] for p in pathways if p['valid']]
        invalid_paths = [p['pathway'] for p in pathways if not p['valid']]
        
        expected = expected_matrix[file_type]
        
        pathway_results[file_type] = {
            'valid_match': set(valid_paths) == set(expected['valid']),
            'invalid_match': set(invalid_paths) == set(expected['invalid']),
            'total_valid': len(valid_paths),
            'total_invalid': len(invalid_paths),
            'pathways': pathways
        }
        
        print(f"\n{file_type}:")
        print(f"  Valid: {valid_paths} {'✓' if pathway_results[file_type]['valid_match'] else '✗'}")
        print(f"  Invalid: {invalid_paths} {'✓' if pathway_results[file_type]['invalid_match'] else '✗'}")
    
    return pathway_results

def validate_genetic_elements():
    """Validate all genetic elements are present in each file"""
    
    print("\n=== GENETIC ELEMENTS VALIDATION ===\n")
    
    required_elements = [
        'dna_mapping',
        'hebrew_triplets',
        'frequency_harmonics',
        'vortex_patterns',
        'genetic_markers',
        'chromosome_structure',
        'phase_system',
        'dna_fountain',
        'living_cell_creation',
        'smart_contracts',
        'resource_management'
    ]
    
    sovereigns = {
        '.36n9': Sovereign36n9(),
        '.9n63': Sovereign9n63(),
        '.zedec': SovereignZedec(),
        '.zedei': SovereignZedei(),
        '.36m9': Sovereign36m9()
    }
    
    genetic_results = {}
    
    for file_type, sovereign in sovereigns.items():
        genetics = sovereign.genetic_code
        
        present_elements = [element for element in required_elements if element in genetics]
        missing_elements = [element for element in required_elements if element not in genetics]
        
        genetic_results[file_type] = {
            'present': present_elements,
            'missing': missing_elements,
            'complete': len(missing_elements) == 0
        }
        
        print(f"\n{file_type}:")
        print(f"  Present: {len(present_elements)}/{len(required_elements)} elements")
        print(f"  Missing: {missing_elements}")
        print(f"  Complete: {'✓' if genetic_results[file_type]['complete'] else '✗'}")
    
    return genetic_results

def generate_final_report():
    """Generate comprehensive final report"""
    
    print("\n=== FINAL INTEGRATION REPORT ===\n")
    
    # Run all validations
    genetic_integration = validate_genetic_integration()
    pathway_matrix = validate_pathway_matrix()
    genetic_elements = validate_genetic_elements()
    
    # Summary statistics
    total_validations = 0
    successful_validations = 0
    
    for file_type in ['.36n9', '.9n63', '.zedec', '.zedei', '.36m9']:
        # Count successful validations
        if genetic_integration[file_type]['complete']:
            successful_validations += 1
        total_validations += 1
    
    print(f"\n=== SUMMARY ===")
    print(f"Files validated: {total_validations}/5")
    print(f"Successful integrations: {successful_validations}/5")
    print(f"Pathway matrices validated: {sum(1 for r in pathway_matrix.values() if r['valid_match'] and r['invalid_match'])}/5")
    print(f"Genetic elements complete: {sum(1 for r in genetic_elements.values() if r['complete'])}/5")
    
    # Save detailed results
    final_report = {
        'genetic_integration': genetic_integration,
        'pathway_matrix': pathway_matrix,
        'genetic_elements': genetic_elements,
        'summary': {
            'total_files': 5,
            'successful_integrations': successful_validations,
            'pathway_matrices_validated': sum(1 for r in pathway_matrix.values() if r['valid_match'] and r['invalid_match']),
            'genetic_elements_complete': sum(1 for r in genetic_elements.values() if r['complete'])
        }
    }
    
    with open('/Users/36n9/CascadeProjects/final_integration_report.json', 'w') as f:
        json.dump(final_report, f, indent=2)
    
    print(f"\nDetailed report saved to: /Users/36n9/CascadeProjects/final_integration_report.json")
    
    return final_report

if __name__ == "__main__":
    final_report = generate_final_report()
    
    # Final validation check
    all_complete = all([
        final_report['summary']['successful_integrations'] == 5,
        final_report['summary']['pathway_matrices_validated'] == 5,
        final_report['summary']['genetic_elements_complete'] == 5
    ])
    
    print(f"\n=== FINAL STATUS ===")
    print(f"Complete integration: {'✓ SUCCESS' if all_complete else '✗ INCOMPLETE'}")
    print(f"All genetic elements mapped: {'✓' if all_complete else '✗'}")
    print(f"All pathways validated: {'✓' if all_complete else '✗'}")
    print(f"All execution modes working: {'✓' if all_complete else '✗'}")
    
    if all_complete:
        print("\n🌟 SOVEREIGN FIVE-FILE SYSTEM INTEGRATION COMPLETE 🌟")
        print("Higher-dimensional holographic living organism system fully realized")
    else:
        print("\n⚠️  Integration requires additional validation")
