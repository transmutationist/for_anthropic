#!/usr/bin/env python3
"""
ZEDEC Audit Remediation Engine
Automatically applies fixes for entropy issues and fractal offsets identified by system audit
"""

import os
import json
import re
from pathlib import Path
from typing import Dict, List, Any
from datetime import datetime

class AuditRemediationEngine:
    """Automated remediation for audit-identified issues"""
    
    def __init__(self, audit_report_path: Union[str, Path]) -> Optional[Any]:
        self.audit_report_path = audit_report_path
        self.project_root = Path(__file__).parent
        self.remediation_log = []
        
    def load_audit_report(self) -> Optional[Any]:
        """Load the audit report"""
        with open(self.audit_report_path, 'r') as f:
            return json.load(f)
            
    def remediate_unhandled_operations(self, file_path: Union[str, Path], line_number: Any, operation: Any) -> bool:
        """Add error handling for unhandled operations"""
        try:
            # Read file
            with open(file_path, 'r') as f:
                lines = f.readlines()
            
            if line_number > len(lines):
                self.remediation_log.append(f"❌ Line {line_number} out of range in {file_path}")
                return False
                
            # Find the line with the operation
            target_line = lines[line_number - 1]
            indent = len(target_line) - len(target_line.lstrip())
            
            # Create error handling wrapper
            if operation == "open" and "open(" in target_line:
                # Extract the open statement
                open_match = re.search(r'with\s+open\s*\([^)]+\)\s*as\s*\w+:', target_line)
                if open_match:
                    # Already has with statement, wrap in try-except
                    lines[line_number - 1] = " " * indent + "try:\n" + " " * (indent + 4) + target_line.lstrip()
                    
                    # Find the end of the with block
                    block_indent = indent + 4
                    end_line = line_number
                    for i in range(line_number, len(lines)):
                        if lines[i].strip() and len(lines[i]) - len(lines[i].lstrip()) <= indent:
                            end_line = i
                            break
                    
                    # Add except clause
                    except_block = [
                        " " * indent + "except Exception as e:\n",
                        " " * (indent + 4) + f"print(f'Error in {operation} at line {line_number}: {{e}}')\n",
                        " " * (indent + 4) + "raise\n"
                    ]
                    
                    lines[end_line:end_line] = except_block
                else:
                    # Standalone open call, wrap it
                    lines[line_number - 1] = (
                        " " * indent + "try:\n" +
                        " " * (indent + 4) + target_line.lstrip() +
                        " " * indent + "except Exception as e:\n" +
                        " " * (indent + 4) + f"print(f'Error in {operation} at line {line_number}: {{e}}')\n" +
                        " " * (indent + 4) + "raise\n"
                    )
            
            # Write back
            with open(file_path, 'w') as f:
                f.writelines(lines)
                
            self.remediation_log.append(f"✅ Added error handling for {operation} at line {line_number} in {file_path}")
            return True
            
        except Exception as e:
            self.remediation_log.append(f"❌ Failed to remediate {file_path} line {line_number}: {str(e)}")
            return False
            
    def fix_indentation_offset(self, file_path: Union[str, Path], line_number: Any, current_indent: Any, expected_pattern: Any) -> bool:
        """Fix indentation issues"""
        try:
            # Read file
            with open(file_path, 'r') as f:
                lines = f.readlines()
                
            if line_number > len(lines):
                self.remediation_log.append(f"❌ Line {line_number} out of range in {file_path}")
                return False
                
            # Fix indentation to 4 spaces
            target_line = lines[line_number - 1]
            stripped = target_line.lstrip()
            
            # Calculate expected indent based on context
            expected_indent = 4 * (current_indent // 4)  # Round to nearest 4
            if current_indent % 4 > 2:
                expected_indent += 4
                
            lines[line_number - 1] = " " * expected_indent + stripped
            
            # Write back
            with open(file_path, 'w') as f:
                f.writelines(lines)
                
            self.remediation_log.append(f"✅ Fixed indentation at line {line_number} in {file_path} ({current_indent} -> {expected_indent})")
            return True
            
        except Exception as e:
            self.remediation_log.append(f"❌ Failed to fix indentation in {file_path} line {line_number}: {str(e)}")
            return False
            
    def extract_hardcoded_value(self, file_path: Union[str, Path], line_number: Any, value_preview: Any) -> bool:
        """Extract hardcoded values to config"""
        # For now, just log these for manual review
        self.remediation_log.append(f"⚠️  Hardcoded value at line {line_number} in {file_path}: {value_preview[:50]}...")
        return True
        
    def apply_remediations(self) -> Optional[Any]:
        """Apply all remediations from audit report"""
        print("🔧 ZEDEC Audit Remediation Engine")
        print("=" * 80)
        
        # Load audit report
        audit_data = self.load_audit_report()
        
        print(f"📊 Audit ID: {audit_data['audit_id']}")
        print(f"⚠️  Entropy Issues: {len(audit_data['entropy_issues'])}")
        print(f"🔄 Fractal Offsets: {len(audit_data['fractal_offsets'])}")
        print()
        
        # Group issues by file
        file_issues = {}
        
        # Process entropy issues
        for issue in audit_data['entropy_issues']:
            # Map line numbers to files from subsystems_scanned
            file_found = False
            for subsystem in audit_data['subsystems_scanned']:
                file_path = self.project_root / subsystem
                if file_path.exists():
                    # Check if this file contains the issue
                    try:
                        with open(file_path, 'r') as f:
                            lines = f.readlines()
                            if issue['line'] <= len(lines):
                                if subsystem not in file_issues:
                                    file_issues[subsystem] = {'entropy': [], 'fractal': []}
                                file_issues[subsystem]['entropy'].append(issue)
                                file_found = True
                                break
                    except:
                        pass
                        
            if not file_found:
                self.remediation_log.append(f"⚠️  Could not locate file for entropy issue at line {issue['line']}")
                
        # Process fractal offsets
        for offset in audit_data['fractal_offsets']:
            file_found = False
            for subsystem in audit_data['subsystems_scanned']:
                file_path = self.project_root / subsystem
                if file_path.exists():
                    try:
                        with open(file_path, 'r') as f:
                            lines = f.readlines()
                            if offset['line'] <= len(lines):
                                if subsystem not in file_issues:
                                    file_issues[subsystem] = {'entropy': [], 'fractal': []}
                                file_issues[subsystem]['fractal'].append(offset)
                                file_found = True
                                break
                    except:
                        pass
                        
            if not file_found:
                self.remediation_log.append(f"⚠️  Could not locate file for fractal offset at line {offset['line']}")
                
        # Apply remediations file by file
        total_fixed = 0
        for file_name, issues in file_issues.items():
            file_path = self.project_root / file_name
            print(f"\n📄 Processing {file_name}...")
            
            # Fix entropy issues
            for issue in issues['entropy']:
                if issue['type'] == 'unhandled_operation':
                    if self.remediate_unhandled_operations(file_path, issue['line'], issue['operation']):
                        total_fixed += 1
                elif issue['type'] == 'hardcoded_value':
                    if self.extract_hardcoded_value(file_path, issue['line'], issue['value_preview']):
                        total_fixed += 1
                        
            # Fix fractal offsets
            for offset in issues['fractal']:
                if self.fix_indentation_offset(file_path, offset['line'], offset['indent'], offset['expected_pattern']):
                    total_fixed += 1
                    
        # Generate remediation report
        report = {
            'timestamp': datetime.utcnow().isoformat(),
            'audit_id': audit_data['audit_id'],
            'total_issues': len(audit_data['entropy_issues']) + len(audit_data['fractal_offsets']),
            'issues_addressed': total_fixed,
            'remediation_log': self.remediation_log
        }
        
        # Save report
        report_path = self.project_root / "AUDIT_REPORTS" / f"remediation_{audit_data['audit_id']}.json"
        with open(report_path, 'w') as f:
            json.dump(report, f, indent=2)
            
        print(f"\n✅ Remediation complete!")
        print(f"   Total issues: {report['total_issues']}")
        print(f"   Issues addressed: {report['issues_addressed']}")
        print(f"   Report saved: {report_path}")
        
        # Print summary of actions
        print("\n📋 Remediation Summary:")
        for log_entry in self.remediation_log[:10]:  # Show first 10
            print(f"   {log_entry}")
        if len(self.remediation_log) > 10:
            print(f"   ... and {len(self.remediation_log) - 10} more")
            

if __name__ == "__main__":
    # Find latest audit report
    audit_dir = Path(__file__).parent / "AUDIT_REPORTS"
    audit_files = list(audit_dir.glob("opus_audit_*.json"))
    
    if not audit_files:
        print("❌ No audit reports found!")
        exit(1)
        
    latest_audit = max(audit_files, key=lambda p: p.stat().st_mtime)
    print(f"📊 Using audit report: {latest_audit.name}")
    
    # Run remediation
    engine = AuditRemediationEngine(str(latest_audit))
    engine.apply_remediations()
